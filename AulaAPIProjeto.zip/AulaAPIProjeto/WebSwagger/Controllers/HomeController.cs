﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebSwagger.Models;

namespace WebSwagger.Controllers
{
    public class HomeController : Controller
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parametro"></param>
        /// <returns></returns>

        [HttpPost("/Home/Login")]
        public JsonResult Login(ParametrosEntrada parametro)
        {
            var retorno = new ParametrosRetorno();

            if (parametro.email == "valdir@valdir.com.br" && parametro.senha == "11234")
            {
                retorno.codigo = 0;
                retorno.nome = "Login com Sucesso";
            }
            else
            {
                retorno.codigo = 1;
                retorno.nome = "usuário não está correto";
            }

            return Json(retorno);
        }


        [HttpGet("/Home/Listaprodutos")]
        public JsonResult Listaprodutos()
        {
            var retorno = new List<ParametrosRetorno>();


            for (int i = 0; i < 20; i++)
            {
                retorno.Add(new ParametrosRetorno
                {
                    codigo = i,
                    nome = string.Concat("Produto - ", i.ToString())
                });
            }


            return Json(retorno);

        }


    }
}
